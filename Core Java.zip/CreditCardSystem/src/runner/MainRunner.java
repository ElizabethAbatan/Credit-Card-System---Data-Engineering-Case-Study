package runner;
import java.sql.SQLException;
import java.util.Scanner;
import creditcardsysDAO.TransactionDAOImplementation;
import creditcardsysDAO.CustomerDAOImplement;
public class MainRunner{

public static void main(String[] args) throws SQLException {

		// TODO Auto-generated method stub

	Scanner input = new Scanner(System.in);
	
	int choice = 0;
	int ssn = 0; 
	int month = 0;
	int year = 0;
	String last_Name = null;
	String middle_Name = null;
	String first_Name = null;
	String Apt_no = null; 
	String Street_name = null;
	String Cust_city = null;
	String Cust_state = null;
	String Cust_country = null;
	String Cust_zip = null;
	String cust_Phone = null;
	String cust_Email = null;
	String zipcode = null;
	String CREDIT_CARD_NO = null;
	String TRANSACTION_TYPE = null;
	
	CustomerDAOImplement custimp = new CustomerDAOImplement();
	TransactionDAOImplementation transimp = new TransactionDAOImplementation();
	
 
	String option = "\nPlease choose from the choices below.\n"
		+ "\n1. Display the transactions made by customers living in a given zipcode for a given month and year.\n"
		+ "\n2. Display the number and total values of transactions for a given type.\n"
		+ "\n3. Display the number and total values of transactions for branches in a given state .\n"
		+ "\n4. Check the existing account details of a customer.\n"
		+ "\n5. Modify the existing account details of a customer.\n"
		+ "\n6. Modify the existing account details of a customer.\n" 
		+ "\n7. Modify the existing account details of a customer.\n"
		+ "\n8. Modify the existing account details of a customer.\n"
		+ "\n9. Generate monthly bill for a credit card number for a given month and year.\n"
		+ "\n10. Display the transactions made by a customer between two dates. Order by year, month, and day in descending order.\n"
		+ "\n11. Quit";
	
		
	System.out.print(option);
	choice = input.nextInt();
	while (choice < 1 || choice > 11) {
		System.out.println("Invaid Entry");
	}
	
	switch (choice) {
	
	case 1:
		System.out.println("Enter Customer's Zipcode");
		zipcode = input.next(); 
		System.out.println("Enter Month");
		month = input.nextInt();
		System.out.println("Enter Year");
		year = input.nextInt();
		transimp.TransactionDetails(zipcode, month, year);
		break;
	
	case 2:
		System.out.println("Enter Customer Transaction's TRANSACTION_TYPE");
		TRANSACTION_TYPE = input.next();
		transimp.TransactionType(TRANSACTION_TYPE);
		break;
		
	case 3:
		System.out.println("Enter State");
		Cust_state = input.next();
		transimp.BranchsTransaction(Cust_state);
		break;
	
	case 4:
		System.out.println("Enter Social Security Number");
		ssn  = input.nextInt();
		custimp.CustomerDetails(ssn);
		break;
	
	case 5:
		System.out.println("Enter Customer's Social Security Number");
		ssn = input.nextInt();
		System.out.println("Enter last_Name");
		last_Name = input.next();
		System.out.println("Enter middle_Name");
		middle_Name = input.next();
		System.out.println("Enter first_Name");
		first_Name = input.next();
		custimp.UpdateCustomerAccount1(ssn, last_Name, middle_Name, first_Name);
		break;
	
	case 6:
		System.out.println("Enter Customer's Apt_no");
		Apt_no = input.next(); 
		System.out.println("Enter Street_name");
		Street_name = input.next();
		System.out.println("Enter Cust_city");
		Cust_city = input.next();
		System.out.println("Enter Cust_state");
		Cust_state = input.next();
		System.out.println("Enter Cust_country");
		Cust_country = input.next();
		System.out.println("Enter Cust_zip");
		Cust_zip = input.next();
		custimp.UpdateCustomerAccount2(Apt_no, Street_name, Cust_city, Cust_state, Cust_country, Cust_zip);
		break;
	
	case 7:
		System.out.println("Enter customer's Phone");
		cust_Phone = input.next();
		custimp.UpdateCustomerAccount3(cust_Phone);
		break;
		
	case 8:
		System.out.println("Enter customer's Email");
		cust_Email = input.next();
		custimp.UpdateCustomerAccount3(cust_Email);
		break;
		
	case 9:
		System.out.println("Enter Customer's creditCardNo");
		CREDIT_CARD_NO = input.next();
		System.out.println("Enter Month");
		month = input.nextInt();
		System.out.println("Enter Year");
		year = input.nextInt();
		custimp.GenerateMonthlyBill(CREDIT_CARD_NO, month, year);
	
	case 10:
		Scanner sc = new Scanner(System.in);
        System.out.print("Please enter Customer SSN: ");
        int SSN = Integer.parseInt(sc.nextLine());

        System.out.println("Format: YYYYMMDD (ie: 20171228)");
        System.out.print("Please enter starting date: ");
        String sDate = sc.nextLine();

        System.out.println("Format: YYYYMMDD (ie: 20171228)");
        System.out.print("Please enter ending date: ");
        String eDate = sc.nextLine();
        custimp.TransactionsByCustomer(SSN, sDate, eDate );

		
	default:
		System.out.println("Quit");
		 //Quit switch	
	
	}
	}
	}


	













	











