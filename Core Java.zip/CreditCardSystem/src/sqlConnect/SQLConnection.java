
package sqlConnect;



import java.sql.*;


public class SQLConnection {

	
	
	public static void main(String[] args) throws SQLException {
		
		final String USERNAME = "root";
		final String PASSWORD = "mysql";
		final String URL = "jdbc:mysql://localhost:3306/new_schema";

		Connection myconn = null;
		//PreparedStatement myPstmt = null;
		//ResultSet myRs = null;			

		myconn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		System.out.println("Database is Connected");
	}
}




 