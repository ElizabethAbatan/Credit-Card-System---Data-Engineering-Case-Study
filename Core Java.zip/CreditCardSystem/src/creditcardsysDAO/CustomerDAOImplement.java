package creditcardsysDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import creditcardsysDAO.CustomerDAO;
import creditcardsysDAO.QueryBank;

public class CustomerDAOImplement implements CustomerDAO {
		 
		 String URL = "jdbc:mysql://localhost:3306/cdw_sapp";
		 String USERNAME = "root";
		 String PASSWORD = "mysql";
		 
		 
		 Connection myConn;
		 PreparedStatement myPstmt;
		 ResultSet myRs ;
		 int result = 0;

		 @Override
		 public void CustomerDetails(int ssn) throws SQLException {
			// TODO Auto-generated method stub
	
		try {
			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
				System.out.println("Database is Connected");
						
					myPstmt = myConn.prepareStatement(QueryBank.CustomerDetails);
					myPstmt.setInt(1, ssn);
					myRs = myPstmt.executeQuery();
				    
					if(myRs.next()) {
			
				System.out.println(myRs.getString("first_Name")+"  "+ myRs.getString("middle_Name")+"  "+ myRs.getString("last_Name"));
				System.out.println(myRs.getString("street_name")+"  "+ myRs.getString("apt_no"));
				System.out.println(myRs.getString("cust_city")+"  "+ myRs.getString("cust_state")+"  "+ myRs.getString("cust_country")+"  "+ myRs.getString("cust_zip"));
	            System.out.println(myRs.getInt("cust_phone"));
	            System.out.println(myRs.getString("cust_email"));
			}
		else	
			{
				System.out.println("SSN entered is invalid");
			}								
		}
		catch (SQLException exc) {
		exc.printStackTrace();
			//throw new RuntimeException(exc);
		}
		
		return ;
		}

	@Override
	public void UpdateCustomerAccount1(int ssn, String last_Name, String middle_Name, String first_Name) throws SQLException {
				
		
		try {
			
			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
			System.out.println("Database is Connected");
			
					myPstmt = myConn.prepareStatement(QueryBank.UpdateCustomerAccount1);
					myPstmt.executeUpdate();
					int result = myPstmt.executeUpdate();
			
			        if (result > 0) {
				
			System.out.println("An existing customer was updated successfully!");
			}
			} catch (SQLException exc) {
			exc.printStackTrace();
			}
			return;
			}
			
				
	@Override
	public void UpdateCustomerAccount2(String Apt_no, String Street_name, String Cust_city, String Cust_state, String Cust_country, String Cust_zip) throws SQLException{
	
		try {
	
			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			myPstmt = myConn.prepareStatement(QueryBank.UpdateCustomerAccount2);
			myPstmt.executeUpdate();
			int result = myPstmt.executeUpdate();
	
			if (result > 0) {
				System.out.println("An existing customer was updated successfully!");
			}
		} catch (SQLException exc) {
			exc.printStackTrace();
		}
		return;

	}

	@Override
	public  void UpdateCustomerAccount3(String cust_Phone) {
		
		try {
	
	myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	myPstmt = myConn.prepareStatement(QueryBank.UpdateCustomerAccount3);
	myPstmt.executeUpdate();
	int result = myPstmt.executeUpdate();
	
	if (result > 0) {
		System.out.println("An existing customer was updated successfully!");
		}
	} catch (SQLException exc) {
	exc.printStackTrace();
	}
	return;
	}

	
	@Override
	public void UpdateCustomerAccount4(String cust_Email) {
		
		try {
			
			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			myPstmt = myConn.prepareStatement(QueryBank.UpdateCustomerAccount4);
			myPstmt.executeUpdate();
			int result = myPstmt.executeUpdate();
			
			if (result > 0) {
				System.out.println("An existing customer was updated successfully!");
			}
		} catch (SQLException exc) {
			exc.printStackTrace();
		}
		return;
	   }

	@Override
	public void GenerateMonthlyBill( String SSN, int Month, int Year) {
	

		try {
			
			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
			System.out.println("Database is Connected");
			
			
			myPstmt = myConn.prepareStatement(QueryBank.GenerateMonthlyBill);
			myPstmt.setString(1, SSN);
			myPstmt.setInt(2, Month);
			myPstmt.setInt(3, Year);
			myRs = myPstmt.executeQuery();
					
			
			if (myRs.next ()) {
	
				System.out.println(myRs.getString("first_Name")+" "+ myRs.getString("middle_Name")+" "+ myRs.getString("last_Name"));
				System.out.println(myRs.getString("street_name")+" "+ myRs.getString("apt_no"));
				System.out.println(myRs.getString("cust_city")+" "+ myRs.getString("cust_state")+" "+ myRs.getString("cust_country")+" "+ myRs.getString("cust_zip"));
	            System.out.println(myRs.getString ("cust_phone"));
	            System.out.println(myRs.getString("cust_email"));	
			}
				
		else 
		{
			System.out.println("Customer's monthly bill is invalid");
		}
		}
		
		catch (SQLException exc) {
				exc.printStackTrace();
		}
		return; 
	    }
	
	
	@Override
	public void TransactionsByCustomer(int ssn, String startdate, String endate) {
		
		try {
			
			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			myPstmt = myConn.prepareStatement(QueryBank.TransactionsByCustomer);
            myPstmt.setInt(1, ssn);
            myPstmt.setInt(2,Integer.parseInt(startdate));
            myPstmt.setInt(3,Integer.parseInt(endate));
            myRs = myPstmt.executeQuery();

			while(myRs.next())
			if (myRs.next () == false) {
	
				System.out.println("Transactions made by customer does not exist");
			}
			else {
				System.out.println(myRs.getInt(1));
                System.out.println(myRs.getInt(2));
                System.out.println(myRs.getInt(3));
                System.out.println(myRs.getInt(4));
                System.out.println(myRs.getString(5));
                System.out.println(myRs.getInt(6));
                System.out.println(myRs.getInt(7));
                System.out.println(myRs.getString(8));
                System.out.println(myRs.getDouble(9));
               // transactions.add(t);

			}
				}catch (SQLException exc) {
				exc.printStackTrace();
	

			}
				return;
			}
	        }

