package creditcardsysDAO;

//package creditcardsysDao;
//import java.sql.SQLException;

import java.sql.SQLException;

public interface CustomerDAO {

	public void CustomerDetails(int ssn) throws SQLException;

	public  void UpdateCustomerAccount1(int ssn, String last_Name, String middle_Name, String first_Name) throws SQLException ;
	
	public  void UpdateCustomerAccount2(String apt_No, String street_Name, String cust_City, String cust_State, String cust_Country, String cust_Zip) throws SQLException;
	
	public  void UpdateCustomerAccount3(String cust_Phone) throws SQLException ;
	
	public  void UpdateCustomerAccount4(String cust_Email) throws SQLException ;

	public  void GenerateMonthlyBill(String CREDIT_CARD_NO, int month, int year) throws SQLException;

	public void TransactionsByCustomer(int ssn, String startdate, String endate) throws SQLException;


	}
	