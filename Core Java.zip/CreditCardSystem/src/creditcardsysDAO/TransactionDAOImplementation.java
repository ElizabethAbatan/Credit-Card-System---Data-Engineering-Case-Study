package creditcardsysDAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class TransactionDAOImplementation implements TransactionDAO {
	
		String URL = "jdbc:mysql://localhost:3306/cdw_sapp";
		String USERNAME = "root";
		String PASSWORD = "mysql";
	 
	 
		Connection myConn;
		PreparedStatement myPstmt;
		ResultSet myRs ;
		int result = 0;
	 
	
		@Override
		public void TransactionDetails(String zipcode, int month, int year) throws SQLException {
		// TODO Auto-generated method stub
	
		try {
		
			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		
				System.out.println("Database is Connected");
		
					myPstmt = myConn.prepareStatement(QueryBank.TransactionDetails);
					myPstmt.setString(1, zipcode);
					myPstmt.setInt(2, month);
					myPstmt.setInt(3, year);
					myRs = myPstmt.executeQuery();
					
					if(myRs.next()) {
			
				System.out.println(myRs.getString("first_Name")+" "+ myRs.getString("middle_Name")+" "+ myRs.getString("last_Name"));
				System.out.println(myRs.getString("street_name")+" "+ myRs.getString("apt_no")+" "+ myRs.getString("cust_city")+" "+ myRs.getString("cust_state"));
				System.out.println(myRs.getString("cust_country")+" "+ myRs.getString("cust_zip")+" "+ myRs.getString ("cust_phone") +" "+ myRs.getString("cust_email"));
				System.out.println(myRs.getString("CREDIT_CARD_NO") +" "+ myRs.getString("transaction_Id")+" "+myRs.getString("transaction_Type")+" "+myRs.getString("transaction_Value"));
				System.out.println(myRs.getString("month")+" "+ myRs.getString("day")+" "+ myRs.getString("year"));
			}
		else 
			{	
				System.out.println("Transactions Does Not Exist");	
			}
		}
		catch (SQLException exc) {
		exc.printStackTrace();
		}
		return;
		}

	@Override
	public void TransactionType(String TRANSACTION_TYPE) throws SQLException {
		// TODO Auto-generated method stub

		try {
			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
			System.out.println("Database is Connected");
						
					myPstmt = myConn.prepareStatement(QueryBank.TransactionType);
					myPstmt.setString(1, TRANSACTION_TYPE);
					myRs = myPstmt.executeQuery();
					
					if(myRs.next()) {
						
						System.out.println("Sum will be " + myRs.getDouble(1) + " and count will be "+ myRs.getInt(2));
			
					}
				else 
				{
			         System.out.println("Transaction Type Does Not Exist");
				}
				}
	           catch (SQLException exc) {
	       	exc.printStackTrace();
	         }
	
	     return;
	       }


	@Override
	public void BranchsTransaction( String state) throws SQLException {
		// TODO Auto-generated method stub

		try {

			myConn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
			System.out.println("Database is Connected");
			
			myPstmt = myConn.prepareStatement(QueryBank.BranchesTransaction);
			myPstmt.setString(1, state);
			myRs = myPstmt.executeQuery();
			
			if(myRs.next()) {
			
				System.out.println("Sum will be " + myRs.getDouble(1) + " and count will be "+ myRs.getInt(2));
			}
		else
			{
				System.out.println("Branch's Transaction Does Not Exist");
		}
			
		}
		catch (SQLException exc) {
			exc.printStackTrace();
		}
		
		return;
		
	}
		
	}

