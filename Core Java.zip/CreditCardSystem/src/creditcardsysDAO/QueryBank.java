package creditcardsysDAO;

public class QueryBank {
         
	
	
	
							//Queries for Customer Details Functional Requirements 
	
	public static final String CustomerDetails = 
	"SELECT * FROM cdw_sapp_customer \r\n"
	+ "LEFT JOIN cdw_sapp_creditcard ON cdw_sapp_customer.SSN = cdw_sapp_creditcard.CUST_SSN \r\n"
	+ "WHERE cdw_sapp_customer.SSN = ?";
	
	public static final String UpdateCustomerAccount1 = 
	"UPDATE cdw_sapp_customer SET last_Name = ?, middle_Name = ?, first_Name = ? WHERE SSN = ? ";
	
	public static final String UpdateCustomerAccount2 = 
	"UPDATE cdw_sapp_customer SET apt_No = ?, street_Name = ?, cust_City = ?, cust_State = ?,"
	+ " cust_Country = ?, cust_Zip = ? WHERE SSN = ?"; 
	
	public static final String UpdateCustomerAccount3 = "UPDATE cdw_sapp_customer SET cust_Phone = ? WHERE SSN = ? " ;
	
	public static final String UpdateCustomerAccount4 = "UPDATE cdw_sapp_customer SET cust_Email = ? WHERE SSN = ? " ;
	
	
	public static final String GenerateMonthlyBill = 
	"SELECT * FROM cdw_sapp_customer csd\r\n"
	+"JOIN cdw_sapp_creditcard csc on csc.CUST_SSN = csd.SSN\r\n"
	+"WHERE csd.SSN = ? AND csc.MONTH = ? AND csc.YEAR = ?";
	
	
	public static final String TransactionsByCustomer =
	"SELECT t.*, CONCAT(t.YEAR, t.MONTH, t.DAY) AS ymd " +
    "FROM CDW_SAPP_CREDITCARD AS t INNER JOIN CDW_SAPP_CUSTOMER AS c ON t.CUST_SSN=c.SSN " +
    "WHERE c.SSN=? " +
    "HAVING (ymd BETWEEN ? AND ?) " +
    "ORDER BY ymd";

			

	
		
							//Queries for Transaction Details Functional Requirements 
	
	public static final String TransactionDetails = 
	"SELECT * FROM cdw_sapp_customer \r\n" 
	+"JOIN cdw_sapp_creditcard  ON cdw_sapp_creditcard.CUST_SSN = cdw_sapp_customer.SSN \r\n" 
	+"WHERE cdw_sapp_customer.CUST_ZIP = ? and cdw_sapp_creditcard.MONTH = ? and cdw_sapp_creditcard.YEAR = ? \r\n"
	+"ORDER BY cdw_sapp_creditcard.DAY DESC";
	
	
	
	public static final String TransactionType = 
	"SELECT SUM(TRANSACTION_VALUE), COUNT(*) " +
    "FROM cdw_sapp_creditcard " +
    "WHERE TRANSACTION_TYPE=? " +
    "GROUP BY TRANSACTION_TYPE";


	
	public static final String BranchesTransaction =
	"SELECT SUM(t.TRANSACTION_VALUE), COUNT(*) " +
    "FROM CDW_SAPP_CREDITCARD as t INNER JOIN CDW_SAPP_BRANCH as b ON t.BRANCH_CODE=b.BRANCH_CODE " +
    "WHERE b.BRANCH_STATE=? " +
    "GROUP BY b.BRANCH_STATE;";

}
