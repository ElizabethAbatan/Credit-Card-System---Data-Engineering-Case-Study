package creditcardsysDAO;
import java.sql.SQLException;
public interface TransactionDAO {

	public void TransactionDetails(String zipcode, int month, int year) throws SQLException;

	public void TransactionType(String TRANSACTION_TYPE) throws SQLException;

	public void BranchsTransaction(String state) throws SQLException;

}
