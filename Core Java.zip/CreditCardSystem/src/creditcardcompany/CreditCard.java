package creditcardcompany;

public class CreditCard {
private String CREDIT_CARD_NO;
private int day;
private int month;
private int year;
private String branchCode;
private String transactionType;	
private double transactionValue;

public CreditCard(String CREDIT_CARD_NO, int day, int month, int year, String branchCode, String transactionType,
		double transactionValue) {
	super();
	this.CREDIT_CARD_NO = CREDIT_CARD_NO;
	this.day = day;
	this.month = month;
	this.year = year;
	this.branchCode = branchCode;
	this.transactionType = transactionType;
	this.transactionValue = transactionValue;
}

public String getCREDIT_CARD_NO() {
	return CREDIT_CARD_NO;
}

public void setCREDIT_CARD_NO(String CREDIT_CARD_NO) {
	this.CREDIT_CARD_NO = CREDIT_CARD_NO;
}

public int getDay() {
	return day;
}

public void setDay(int day) {
	this.day = day;
}

public int getMonth() {
	return month;
}

public void setMonth(int month) {
	this.month = month;
}

public int getYear() {
	return year;
}

public void setYear(int year) {
	this.year = year;
}

public String getBranchCode() {
	return branchCode;
}

public void setBranchCode(String branchCode) {
	this.branchCode = branchCode;
}

public String getTransactionType() {
	return transactionType;
}

public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}

public double getTransactionValue() {
	return transactionValue;
}

public void setTransactionValue(double transactionValue) {
	this.transactionValue = transactionValue;
}


}