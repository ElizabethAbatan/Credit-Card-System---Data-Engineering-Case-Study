package creditcardcompany;

public class Customer {
	private int ssn;
	private String first_name;
	private String middle_name;
	private String last_name;
	private String CREDIT_CARD_NO;
	private String street_name;
	private String apt_no;
	private String cust_city;
	private String cust_state;
	private String cust_country;
    private String cust_zip;
	private String cust_phone;
	private String cust_email;
	private String last_update;
	public Customer(int ssn, String first_name, String middle_name, String last_name, String CREDIT_CARD_NO,
			String street_name, String apt_no, String cust_city, String cust_state, String cust_country,
			String cust_zip, String cust_phone, String cust_email, String last_update) {
		super();
		this.ssn = ssn;
		this.first_name = first_name;
		this.middle_name = middle_name;
		this.last_name = last_name;
		this.CREDIT_CARD_NO = CREDIT_CARD_NO;
		this.street_name = street_name;
		this.apt_no = apt_no;
		this.cust_city = cust_city;
		this.cust_state = cust_state;
		this.cust_country = cust_country;
		this.cust_zip = cust_zip;
		this.cust_phone = cust_phone;
		this.cust_email = cust_email;
		this.last_update = last_update;
	}
	public int getSsn() {
		return ssn;
	}
	public void setSsn(int ssn) {
		this.ssn = ssn;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getCREDIT_CARD_NO() {
		return CREDIT_CARD_NO;
	}
	public void setcreditCardNo(String CREDIT_CARD_NO) {
		this.CREDIT_CARD_NO = CREDIT_CARD_NO;
	}
	public String getStreet_name() {
		return street_name;
	}
	public void setStreet_name(String street_name) {
		this.street_name = street_name;
	}
	public String getApt_no() {
		return apt_no;
	}
	public void setApt_no(String apt_no) {
		this.apt_no = apt_no;
	}
	public String getCust_city() {
		return cust_city;
	}
	public void setCust_city(String cust_city) {
		this.cust_city = cust_city;
	}
	public String getCust_state() {
		return cust_state;
	}
	public void setCust_state(String cust_state) {
		this.cust_state = cust_state;
	}
	public String getCust_country() {
		return cust_country;
	}
	public void setCust_country(String cust_country) {
		this.cust_country = cust_country;
	}
	public String getCust_zip() {
		return cust_zip;
	}
	public void setCust_zip(String cust_zip) {
		this.cust_zip = cust_zip;
	}
	public String getCust_phone() {
		return cust_phone;
	}
	public void setCust_phone(String cust_phone) {
		this.cust_phone = cust_phone;
	}
	public String getCust_email() {
		return cust_email;
	}
	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}
	public String getLast_update() {
		return last_update;
	}
	public void setLast_update(String last_update) {
		this.last_update = last_update;
	}

}
