package creditcardcompany;

public class Branch {
private String branch_code; 
private String branch_name;       
private String branch_street;     
private String branch_city;       
private String branch_state;       
private String branch_zip;       
private String branch_phone;      
private String last_updated;
public Branch(String branch_code, String branch_name, String branch_street, String branch_city, String branch_state,
		String branch_zip, String branch_phone, String last_updated) {
	super();
	this.branch_code = branch_code;
	this.branch_name = branch_name;
	this.branch_street = branch_street;
	this.branch_city = branch_city;
	this.branch_state = branch_state;
	this.branch_zip = branch_zip;
	this.branch_phone = branch_phone;
	this.last_updated = last_updated;
}
public String getBranch_code() {
	return branch_code;
}
public void setBranch_code(String branch_code) {
	this.branch_code = branch_code;
}
public String getBranch_name() {
	return branch_name;
}
public void setBranch_name(String branch_name) {
	this.branch_name = branch_name;
}
public String getBranch_street() {
	return branch_street;
}
public void setBranch_street(String branch_street) {
	this.branch_street = branch_street;
}
public String getBranch_city() {
	return branch_city;
}
public void setBranch_city(String branch_city) {
	this.branch_city = branch_city;
}
public String getBranch_state() {
	return branch_state;
}
public void setBranch_state(String branch_state) {
	this.branch_state = branch_state;
}
public String getBranch_zip() {
	return branch_zip;
}
public void setBranch_zip(String branch_zip) {
	this.branch_zip = branch_zip;
}
public String getBranch_phone() {
	return branch_phone;
}
public void setBranch_phone(String branch_phone) {
	this.branch_phone = branch_phone;
}
public String getLast_updated() {
	return last_updated;
}
public void setLast_updated(String last_updated) {
	this.last_updated = last_updated;
}      

}
